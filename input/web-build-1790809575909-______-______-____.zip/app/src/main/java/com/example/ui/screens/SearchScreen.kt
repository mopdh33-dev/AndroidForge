package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.WorkshopRepository
import com.example.ui.components.StatusBadge
import com.example.ui.components.WorkshopTopBar
import com.example.ui.theme.DebtRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.WorkshopViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SearchScreen(
    viewModel: WorkshopViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    var searchQuery by remember { mutableStateOf("") }
    val ordersWithMods by viewModel.ordersWithMods.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val expenses by viewModel.expenses.collectAsState()

    val currentMonthStr = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
    val searchSuggestions = listOf("باب رئيسي", "شبابيك", "درابزين", "حديد", currentMonthStr)

    val cleanQuery = searchQuery.trim()

    // Matching orders by: customerName, customerPhone, month (orderDate), or workType
    val matchingOrders = if (cleanQuery.isBlank()) emptyList() else {
        ordersWithMods.filter { item ->
            val ord = item.order
            ord.customerName.contains(cleanQuery, ignoreCase = true) ||
            ord.customerPhone.contains(cleanQuery, ignoreCase = true) ||
            ord.workType.contains(cleanQuery, ignoreCase = true) ||
            ord.orderDate.contains(cleanQuery, ignoreCase = true) ||
            ord.description.contains(cleanQuery, ignoreCase = true) ||
            ord.measurements.contains(cleanQuery, ignoreCase = true)
        }
    }

    // Matching customers by: name, phone, location
    val matchingCustomers = if (cleanQuery.isBlank()) emptyList() else {
        customers.filter { c ->
            c.name.contains(cleanQuery, ignoreCase = true) ||
            c.phone.contains(cleanQuery, ignoreCase = true) ||
            c.location.contains(cleanQuery, ignoreCase = true)
        }
    }

    // Matching expenses by: category, date, note
    val matchingExpenses = if (cleanQuery.isBlank()) emptyList() else {
        expenses.filter { exp ->
            exp.category.contains(cleanQuery, ignoreCase = true) ||
            exp.date.contains(cleanQuery, ignoreCase = true) ||
            exp.note.contains(cleanQuery, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            WorkshopTopBar(
                title = "البحث الشامل في الورشة",
                subtitle = "بالاسم، الهاتف، الشهر، أو نوع العمل",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Text Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("اكتب اسم العميل، الهاتف، الشهر، أو نوع العمل...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("global_search_input"),
                singleLine = true
            )

            // Suggestions row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "اقتراحات:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
                searchSuggestions.forEach { s ->
                    FilterChip(
                        selected = searchQuery == s,
                        onClick = { searchQuery = s },
                        label = { Text(s, fontSize = 12.sp) }
                    )
                }
            }

            if (cleanQuery.isBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "ابحث عن أي طلب أو عميل أو مصروف أو شهر",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "يعمل البحث بالاسم أو الهاتف أو نوع العمل (مثل باب، شباك) أو الشهر (مثال: $currentMonthStr)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else if (matchingOrders.isEmpty() && matchingCustomers.isEmpty() && matchingExpenses.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لم يتم العثور على أي نتائج تطابق: $cleanQuery",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Orders Section
                    if (matchingOrders.isNotEmpty()) {
                        item {
                            SectionHeader(
                                title = "الطلبات المطابقة (${matchingOrders.size})",
                                icon = Icons.Default.Assignment
                            )
                        }
                        items(matchingOrders, key = { "order_${it.order.id}" }) { item ->
                            val ord = item.order
                            Card(
                                onClick = { viewModel.navigateTo(Screen.OrderDetail(ord.id)) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${ord.customerName} - ${ord.workType}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "هاتف: ${ord.customerPhone} • التاريخ: ${ord.orderDate}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (ord.measurements.isNotBlank()) {
                                            Text(
                                                text = "المقاس: ${ord.measurements}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        StatusBadge(status = ord.status)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${WorkshopRepository.formatAmount(item.totalPrice)} ${ord.currency}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Customers Section
                    if (matchingCustomers.isNotEmpty()) {
                        item {
                            SectionHeader(
                                title = "العملاء المطابقين (${matchingCustomers.size})",
                                icon = Icons.Default.People
                            )
                        }
                        items(matchingCustomers, key = { "customer_${it.id}" }) { c ->
                            Card(
                                onClick = { viewModel.navigateTo(Screen.CustomerDetail(c.id)) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(c.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(c.phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        if (c.location.isNotBlank()) {
                                            Text(c.location, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }
                                    }
                                    Surface(
                                        color = Color(0xFFDBEAFE),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "فتح العميل",
                                            color = Color(0xFF1D4ED8),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Expenses Section
                    if (matchingExpenses.isNotEmpty()) {
                        item {
                            SectionHeader(
                                title = "المصاريف المطابقة (${matchingExpenses.size})",
                                icon = Icons.Default.ReceiptLong
                            )
                        }
                        items(matchingExpenses, key = { "exp_${it.id}" }) { exp ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("${exp.category} - ${exp.note}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(exp.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = "${WorkshopRepository.formatAmount(exp.amount)} ${exp.currency}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = DebtRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}
