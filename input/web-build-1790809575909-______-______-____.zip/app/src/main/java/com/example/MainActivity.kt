package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.screens.AccountsPartnershipScreen
import com.example.ui.screens.CustomerDetailScreen
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MonthlyReportsScreen
import com.example.ui.screens.NewOrderScreen
import com.example.ui.screens.OrderDetailScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsBackupScreen
import com.example.ui.screens.WithdrawalsScreen
import com.example.ui.theme.WorkshopTheme
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.WorkshopViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: WorkshopViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            WorkshopTheme {
                // Ensure full Arabic Right-to-Left (RTL) layout
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .safeDrawingPadding(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        WorkshopApp(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun WorkshopApp(viewModel: WorkshopViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val context = LocalContext.current

    // Display toast feedback on database changes
    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    // Hardware/gesture BackHandler
    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (val screen = currentScreen) {
            is Screen.Home -> {
                HomeScreen(viewModel = viewModel)
            }
            is Screen.NewOrder -> {
                NewOrderScreen(
                    viewModel = viewModel,
                    prefilledCustomerId = screen.prefilledCustomerId,
                    editingOrderId = screen.editingOrderId,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.OrdersList -> {
                OrdersScreen(
                    viewModel = viewModel,
                    initialStatusFilter = screen.filterStatus,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.OrderDetail -> {
                OrderDetailScreen(
                    orderId = screen.orderId,
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.CustomersList -> {
                CustomersScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.CustomerDetail -> {
                CustomerDetailScreen(
                    customerId = screen.customerId,
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.ExpensesList -> {
                ExpensesScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.WithdrawalsList -> {
                WithdrawalsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.AccountsPartnership -> {
                AccountsPartnershipScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.MonthlyReports -> {
                MonthlyReportsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.Search -> {
                SearchScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
            is Screen.SettingsBackup -> {
                SettingsBackupScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateBack() }
                )
            }
        }
    }
}
