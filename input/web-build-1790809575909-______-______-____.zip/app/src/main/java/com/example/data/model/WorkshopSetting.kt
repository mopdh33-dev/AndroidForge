package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workshop_settings")
data class WorkshopSetting(
    @PrimaryKey
    val key: String,
    val value: String
)

object SettingKeys {
    const val MOHAMMED_PERCENTAGE = "mohammed_percentage"
    const val RAHEN_PERCENTAGE = "rahen_percentage"
    const val DEFAULT_CURRENCY = "default_currency"
    const val WORKSHOP_NAME = "workshop_name"
    const val WORKSHOP_PHONE = "workshop_phone"
    const val WORKSHOP_ADDRESS = "workshop_address"
}
