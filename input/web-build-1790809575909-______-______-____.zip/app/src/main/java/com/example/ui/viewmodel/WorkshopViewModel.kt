package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.WorkshopDatabase
import com.example.data.model.CurrencyFinancialSummary
import com.example.data.model.Customer
import com.example.data.model.CustomerWithStats
import com.example.data.model.Expense
import com.example.data.model.Order
import com.example.data.model.OrderModification
import com.example.data.model.OrderStatus
import com.example.data.model.OrderWithModifications
import com.example.data.model.PartnerWithdrawal
import com.example.data.model.Partners
import com.example.data.model.SettingKeys
import com.example.data.model.WithdrawalSources
import com.example.data.repository.WorkshopRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Screen {
    object Home : Screen()
    data class NewOrder(val prefilledCustomerId: Long? = null, val editingOrderId: Long? = null) : Screen()
    data class OrdersList(val filterStatus: String? = null) : Screen()
    data class OrderDetail(val orderId: Long) : Screen()
    object CustomersList : Screen()
    data class CustomerDetail(val customerId: Long) : Screen()
    object ExpensesList : Screen()
    object WithdrawalsList : Screen()
    object AccountsPartnership : Screen()
    object MonthlyReports : Screen()
    object Search : Screen()
    object SettingsBackup : Screen()
}

class WorkshopViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WorkshopRepository

    // Screen navigation stack
    private val _screenStack = mutableListOf<Screen>(Screen.Home)
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    val ordersWithMods: StateFlow<List<OrderWithModifications>>
    val customers: StateFlow<List<Customer>>
    val expenses: StateFlow<List<Expense>>
    val withdrawals: StateFlow<List<PartnerWithdrawal>>

    val mohammedPercentage: StateFlow<Double>
    val rahenPercentage: StateFlow<Double>
    val defaultCurrency: StateFlow<String>
    val workshopName: StateFlow<String>
    val workshopPhone: StateFlow<String>
    val workshopAddress: StateFlow<String>

    val financialSummaries: StateFlow<List<CurrencyFinancialSummary>>

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Monthly Report selection
    private val _selectedMonth = MutableStateFlow(
        SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
    )
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    val monthlyFinancialSummaries: StateFlow<List<CurrencyFinancialSummary>>

    // Notification / Toast message for user feedback
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        val database = WorkshopDatabase.getDatabase(application)
        repository = WorkshopRepository(database)

        customers = repository.getAllCustomers()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        ordersWithMods = repository.getAllOrdersWithModifications()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        expenses = repository.getAllExpenses()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        withdrawals = repository.getAllWithdrawals()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        mohammedPercentage = repository.getSetting(SettingKeys.MOHAMMED_PERCENTAGE, "50")
            .combine(MutableStateFlow(Unit)) { str, _ -> str.toDoubleOrNull() ?: 50.0 }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 50.0)

        rahenPercentage = repository.getSetting(SettingKeys.RAHEN_PERCENTAGE, "50")
            .combine(MutableStateFlow(Unit)) { str, _ -> str.toDoubleOrNull() ?: 50.0 }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 50.0)

        defaultCurrency = repository.getSetting(SettingKeys.DEFAULT_CURRENCY, "د.ع")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "د.ع")

        workshopName = repository.getSetting(SettingKeys.WORKSHOP_NAME, "ورشة محمد & راهن للحدادة والأبواب")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ورشة محمد & راهن للحدادة والأبواب")

        workshopPhone = repository.getSetting(SettingKeys.WORKSHOP_PHONE, "")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

        workshopAddress = repository.getSetting(SettingKeys.WORKSHOP_ADDRESS, "")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

        // Overall financial summaries
        financialSummaries = combine(
            ordersWithMods,
            expenses,
            withdrawals,
            mohammedPercentage,
            rahenPercentage
        ) { orders, exps, withs, mPct, rPct ->
            WorkshopRepository.calculateSummaries(orders, exps, withs, mPct, rPct)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Monthly financial summaries
        val partnerPercentages = combine(mohammedPercentage, rahenPercentage) { m, r -> Pair(m, r) }
        monthlyFinancialSummaries = combine(
            ordersWithMods,
            expenses,
            withdrawals,
            partnerPercentages,
            _selectedMonth
        ) { orders, exps, withs, pair, monthPrefix ->
            val (mPct, rPct) = pair
            val monthOrders = orders.filter { it.order.orderDate.startsWith(monthPrefix) }
            val monthExpenses = exps.filter { it.date.startsWith(monthPrefix) }
            val monthWithdrawals = withs.filter { it.date.startsWith(monthPrefix) }
            WorkshopRepository.calculateSummaries(monthOrders, monthExpenses, monthWithdrawals, mPct, rPct)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Initialize sample demo data on first launch
        viewModelScope.launch {
            repository.seedSampleDataIfNeeded()
        }
    }

    // Navigation
    fun navigateTo(screen: Screen) {
        _screenStack.add(screen)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (_screenStack.size > 1) {
            _screenStack.removeAt(_screenStack.lastIndex)
            _currentScreen.value = _screenStack.last()
            return true
        }
        return false
    }

    fun navigateToHome() {
        _screenStack.clear()
        _screenStack.add(Screen.Home)
        _currentScreen.value = Screen.Home
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectMonth(month: String) {
        _selectedMonth.value = month
    }

    // Customer operations
    fun createOrGetCustomer(name: String, phone: String, location: String = "", notes: String = ""): Long {
        val finalName = if (name.isBlank()) "زبون بدون اسم" else name.trim()
        val existing = customers.value.firstOrNull {
            it.phone.isNotBlank() && it.phone == phone.trim()
        }
        if (existing != null) {
            return existing.id
        }
        var newId = 0L
        viewModelScope.launch {
            newId = repository.insertCustomer(
                Customer(
                    name = finalName,
                    phone = phone.trim(),
                    location = location.trim(),
                    notes = notes.trim()
                )
            )
        }
        return newId
    }

    fun saveCustomer(customer: Customer) {
        viewModelScope.launch {
            if (customer.id == 0L) {
                repository.insertCustomer(customer)
                showMessage("تمت إضافة العميل بنجاح")
            } else {
                repository.updateCustomer(customer)
                showMessage("تم تعديل بيانات العميل بنجاح")
            }
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            showMessage("تم حذف العميل")
        }
    }

    // Order operations
    fun saveOrder(
        orderId: Long,
        customerId: Long?,
        customerName: String,
        customerPhone: String,
        location: String,
        workType: String,
        description: String,
        measurements: String,
        price: Double,
        paidAmount: Double,
        currency: String,
        orderDate: String,
        deliveryDate: String,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val finalCustomerName = if (customerName.isBlank()) "زبون ورشة" else customerName.trim()

            // Resolve or create customer if needed
            val resolvedCustomerId: Long = if (customerId != null && customerId > 0) {
                customerId
            } else {
                val matched = customers.value.firstOrNull {
                    customerPhone.isNotBlank() && it.phone == customerPhone.trim()
                }
                matched?.id ?: repository.insertCustomer(
                    Customer(
                        name = finalCustomerName,
                        phone = customerPhone.trim(),
                        location = location.trim()
                    )
                )
            }

            val finalOrderDate = if (orderDate.isBlank()) {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            } else orderDate.trim()

            val order = Order(
                id = orderId,
                customerId = resolvedCustomerId,
                customerName = finalCustomerName,
                customerPhone = customerPhone.trim(),
                location = location.trim(),
                workType = workType.trim(),
                description = description.trim(),
                measurements = measurements.trim(),
                price = price,
                paidAmount = paidAmount,
                currency = currency,
                orderDate = finalOrderDate,
                deliveryDate = deliveryDate.trim(),
                status = status,
                notes = notes.trim()
            )

            if (orderId == 0L) {
                val newId = repository.insertOrder(order)
                showMessage("تم تسجيل الطلب بنجاح")
                navigateTo(Screen.OrderDetail(newId))
            } else {
                repository.updateOrder(order)
                showMessage("تم حفظ تعديلات الطلب بنجاح")
            }
        }
    }

    fun updateOrderPayment(orderId: Long, additionalPayment: Double) {
        viewModelScope.launch {
            val orderWithMod = ordersWithMods.value.firstOrNull { it.order.id == orderId }
            if (orderWithMod != null) {
                val currentPaid = orderWithMod.order.paidAmount
                val newPaid = currentPaid + additionalPayment
                repository.updateOrderPaidAmount(orderId, newPaid)
                showMessage("تم تسجيل دفعة بقيمة ${WorkshopRepository.formatAmount(additionalPayment)} ${orderWithMod.order.currency}")
            }
        }
    }

    fun updateOrderStatus(orderId: Long, status: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, status)
            showMessage("تم تحديث حالة الطلب إلى $status")
        }
    }

    fun deleteOrder(orderId: Long) {
        viewModelScope.launch {
            repository.deleteOrderById(orderId)
            showMessage("تم حذف الطلب بنجاح")
            navigateBack()
        }
    }

    // Additional Work / Modification for an order
    fun addOrderModification(
        orderId: Long,
        title: String,
        description: String,
        additionalPrice: Double,
        additionalPaid: Double
    ) {
        viewModelScope.launch {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            repository.insertModification(
                OrderModification(
                    orderId = orderId,
                    title = title.trim(),
                    description = description.trim(),
                    additionalPrice = additionalPrice,
                    additionalPaid = additionalPaid,
                    date = todayStr
                )
            )
            showMessage("تمت إضافة التعديل / العمل الإضافي بنجاح")
        }
    }

    fun deleteOrderModification(modId: Long) {
        viewModelScope.launch {
            repository.deleteModificationById(modId)
            showMessage("تم حذف التعديل")
        }
    }

    // Expense operations
    fun addExpense(
        category: String,
        amount: Double,
        currency: String,
        date: String,
        note: String
    ) {
        viewModelScope.launch {
            val finalDate = if (date.isBlank()) {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            } else date.trim()

            repository.insertExpense(
                Expense(
                    category = category,
                    amount = amount,
                    currency = currency,
                    date = finalDate,
                    note = note.trim()
                )
            )
            showMessage("تم تسجيل المصروف بنجاح")
        }
    }

    fun deleteExpense(expenseId: Long) {
        viewModelScope.launch {
            repository.deleteExpenseById(expenseId)
            showMessage("تم حذف المصروف")
        }
    }

    // Withdrawal operations
    fun addWithdrawal(
        partnerName: String,
        amount: Double,
        currency: String,
        date: String,
        reason: String,
        fromSource: String
    ) {
        viewModelScope.launch {
            val finalDate = if (date.isBlank()) {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            } else date.trim()

            repository.insertWithdrawal(
                PartnerWithdrawal(
                    partnerName = partnerName,
                    amount = amount,
                    currency = currency,
                    date = finalDate,
                    reason = reason.trim(),
                    fromSource = fromSource
                )
            )
            showMessage("تم تسجيل السحب بنجاح للشريك $partnerName")
        }
    }

    fun deleteWithdrawal(withdrawal: PartnerWithdrawal) {
        viewModelScope.launch {
            repository.deleteWithdrawal(withdrawal)
            showMessage("تم حذف السحب")
        }
    }

    // Settings
    fun updatePartnerPercentages(mohammed: Double, rahen: Double) {
        viewModelScope.launch {
            repository.setSetting(SettingKeys.MOHAMMED_PERCENTAGE, mohammed.toString())
            repository.setSetting(SettingKeys.RAHEN_PERCENTAGE, rahen.toString())
            showMessage("تم تحديث نسب الشراكة بنجاح")
        }
    }

    fun updateDefaultCurrency(currency: String) {
        viewModelScope.launch {
            repository.setSetting(SettingKeys.DEFAULT_CURRENCY, currency)
            showMessage("تم تحديث العملة الافتراضية")
        }
    }

    fun updateWorkshopInfo(name: String, phone: String, address: String) {
        viewModelScope.launch {
            repository.setSetting(SettingKeys.WORKSHOP_NAME, name.trim())
            repository.setSetting(SettingKeys.WORKSHOP_PHONE, phone.trim())
            repository.setSetting(SettingKeys.WORKSHOP_ADDRESS, address.trim())
            showMessage("تم حفظ بيانات الورشة بنجاح")
        }
    }

    fun reloadSampleData() {
        viewModelScope.launch {
            repository.seedSampleDataIfNeeded()
            showMessage("تم تحميل بيانات الورشة التجريبية بنجاح")
        }
    }

    // Customer Statistics
    fun getCustomerWithStats(customer: Customer): CustomerWithStats {
        val customerOrders = ordersWithMods.value.filter { it.order.customerId == customer.id }
        val currency = customerOrders.firstOrNull()?.order?.currency ?: defaultCurrency.value
        val totalAmount = customerOrders.sumOf { it.totalPrice }
        val totalPaid = customerOrders.sumOf { it.totalPaid }
        val remaining = customerOrders.sumOf { it.totalRemaining }

        return CustomerWithStats(
            customer = customer,
            ordersCount = customerOrders.size,
            totalOrdersAmount = totalAmount,
            totalPaid = totalPaid,
            totalRemaining = remaining,
            currency = currency
        )
    }
}
