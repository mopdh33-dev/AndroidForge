package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "order_modifications",
    indices = [Index("orderId")]
)
data class OrderModification(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderId: Long,
    val title: String,
    val description: String = "",
    val additionalPrice: Double = 0.0,
    val additionalPaid: Double = 0.0,
    val date: String,
    val createdAt: Long = System.currentTimeMillis()
)
