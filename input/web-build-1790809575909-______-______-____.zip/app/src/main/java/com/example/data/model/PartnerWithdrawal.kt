package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object Partners {
    const val MOHAMMED = "محمد"
    const val RAHEN = "راهن"

    val partnersList = listOf(MOHAMMED, RAHEN)
}

object WithdrawalSources {
    const val PARTNERSHIP_FUNDS = "من حساب الشراكة"
    const val OTHER_PARTNER_FUNDS = "من أموال الشريك الآخر"

    val allSources = listOf(PARTNERSHIP_FUNDS, OTHER_PARTNER_FUNDS)
}

@Entity(
    tableName = "partner_withdrawals",
    indices = [
        Index("partnerName"),
        Index("date")
    ]
)
data class PartnerWithdrawal(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val partnerName: String,
    val amount: Double,
    val currency: String = "د.ع",
    val date: String,
    val reason: String = "",
    val fromSource: String = WithdrawalSources.PARTNERSHIP_FUNDS,
    val createdAt: Long = System.currentTimeMillis()
)
