package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderStatus
import com.example.data.repository.WorkshopRepository
import com.example.ui.theme.DebtRed
import com.example.ui.theme.ForgeAmberDark
import com.example.ui.theme.ForgeAmberLight
import com.example.ui.theme.ForgeAmberPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SteelDark
import com.example.ui.theme.SteelSlate
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.WorkshopViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: WorkshopViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.ordersWithMods.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val summaries by viewModel.financialSummaries.collectAsState()
    val defaultCurrency by viewModel.defaultCurrency.collectAsState()

    val activeOrdersCount = orders.count { it.order.status == OrderStatus.IN_PROGRESS }
    val primarySummary = summaries.firstOrNull { it.currency == defaultCurrency } ?: summaries.firstOrNull()

    val todayFormatted = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).format(Date())

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_grid"),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Header & Branding
        item(span = { GridItemSpan(2) }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_workshop_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(SteelDark, SteelSlate, Color(0xFF2A364F))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(ForgeAmberPrimary, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Engineering,
                                    contentDescription = null,
                                    tint = SteelDark,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "حسابات الورشة",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "محمد & راهن • حديد وتلحيم وأبواب",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = ForgeAmberLight
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Quick summary row inside hero
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "الطلبات قيد التنفيذ",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "$activeOrdersCount طلبات",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ForgeAmberLight
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "صافي الربح الفعلي",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "${WorkshopRepository.formatAmount(primarySummary?.netCashProfit ?: 0.0)} ${primarySummary?.currency ?: defaultCurrency}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if ((primarySummary?.netCashProfit ?: 0.0) >= 0) ProfitGreen else DebtRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = todayFormatted,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }

        // Primary Big Action: Add New Order
        item(span = { GridItemSpan(2) }) {
            Button(
                onClick = { viewModel.navigateTo(Screen.NewOrder()) },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ForgeAmberPrimary,
                    contentColor = SteelDark
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("action_add_new_order")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إضافة طلب جديد",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 8 Grid Cards for the remaining sections
        item {
            WorkshopActionCard(
                title = "طلبات الزبائن",
                subtitle = "${orders.size} طلب مسجل",
                badgeText = "$activeOrdersCount جاري",
                icon = Icons.Default.Assignment,
                iconTint = ForgeAmberDark,
                iconBg = Color(0xFFFEF3C7),
                testTag = "action_orders_list",
                onClick = { viewModel.navigateTo(Screen.OrdersList()) }
            )
        }

        item {
            WorkshopActionCard(
                title = "العملاء",
                subtitle = "${customers.size} عميل مسجل",
                icon = Icons.Default.People,
                iconTint = Color(0xFF2563EB),
                iconBg = Color(0xFFDBEAFE),
                testTag = "action_customers_list",
                onClick = { viewModel.navigateTo(Screen.CustomersList) }
            )
        }

        item {
            WorkshopActionCard(
                title = "المصاريف",
                subtitle = "${expenses.size} حركة منصرفة",
                icon = Icons.Default.ReceiptLong,
                iconTint = Color(0xFFDC2626),
                iconBg = Color(0xFFFEE2E2),
                testTag = "action_expenses_list",
                onClick = { viewModel.navigateTo(Screen.ExpensesList) }
            )
        }

        item {
            WorkshopActionCard(
                title = "السحوبات",
                subtitle = "سحوبات محمد وراهن",
                icon = Icons.Default.AccountBalanceWallet,
                iconTint = Color(0xFF7C3AED),
                iconBg = Color(0xFFEDE9FE),
                testTag = "action_withdrawals_list",
                onClick = { viewModel.navigateTo(Screen.WithdrawalsList) }
            )
        }

        item(span = { GridItemSpan(2) }) {
            WorkshopWideActionCard(
                title = "الحسابات والشراكة",
                description = "حساب الأرباح والخسائر وحصص الشريكين والتسوية النهائية بدقة",
                icon = Icons.Default.Calculate,
                iconTint = Color(0xFF059669),
                iconBg = Color(0xFFD1FAE5),
                testTag = "action_accounts_partnership",
                onClick = { viewModel.navigateTo(Screen.AccountsPartnership) }
            )
        }

        item {
            WorkshopActionCard(
                title = "التقارير الشهرية",
                subtitle = "كشف أرباح مفصل لكل شهر",
                icon = Icons.Default.Assessment,
                iconTint = Color(0xFF0284C7),
                iconBg = Color(0xFFE0F2FE),
                testTag = "action_monthly_reports",
                onClick = { viewModel.navigateTo(Screen.MonthlyReports) }
            )
        }

        item {
            WorkshopActionCard(
                title = "البحث",
                subtitle = "بالاسم، الهاتف، أو العمل",
                icon = Icons.Default.Search,
                iconTint = Color(0xFF4B5563),
                iconBg = Color(0xFFF3F4F6),
                testTag = "action_search",
                onClick = { viewModel.navigateTo(Screen.Search) }
            )
        }

        item(span = { GridItemSpan(2) }) {
            WorkshopWideActionCard(
                title = "الإعدادات والنسخ الاحتياطي",
                description = "تعديل نسب الشراكة، العملة، وحفظ واسترجاع بيانات الورشة محلياً",
                icon = Icons.Default.Settings,
                iconTint = Color(0xFF475569),
                iconBg = Color(0xFFE2E8F0),
                testTag = "action_settings_backup",
                onClick = { viewModel.navigateTo(Screen.SettingsBackup) }
            )
        }
    }
}

@Composable
fun WorkshopActionCard(
    title: String,
    subtitle: String,
    badgeText: String? = null,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(iconBg, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (!badgeText.isNullOrBlank()) {
                    Surface(
                        color = ForgeAmberLight,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelSmall,
                            color = ForgeAmberDark,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun WorkshopWideActionCard(
    title: String,
    description: String,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(iconBg, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
