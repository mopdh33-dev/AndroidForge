package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.WorkshopSetting
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkshopSettingDao {
    @Query("SELECT * FROM workshop_settings")
    fun getAllSettings(): Flow<List<WorkshopSetting>>

    @Query("SELECT * FROM workshop_settings WHERE `key` = :key LIMIT 1")
    fun getSetting(key: String): Flow<WorkshopSetting?>

    @Query("SELECT * FROM workshop_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSettingDirect(key: String): WorkshopSetting?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: WorkshopSetting)

    @Query("INSERT OR REPLACE INTO workshop_settings (`key`, `value`) VALUES (:key, :value)")
    suspend fun setSettingValue(key: String, value: String)
}
