package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object OrderStatus {
    const val IN_PROGRESS = "قيد التنفيذ"
    const val COMPLETED = "مكتمل"
    const val DELIVERED = "تم التسليم"
    const val CANCELLED = "ملغي"

    val allStatuses = listOf(IN_PROGRESS, COMPLETED, DELIVERED, CANCELLED)
}

object WorkTypes {
    val commonTypes = listOf(
        "باب رئيسي حديد",
        "باب سحاب / ليزر",
        "شبابيك حماية",
        "درابزين درج وبلكونة",
        "مظلة كيربي / ساندوتش بنل",
        "سياج حديد / سور",
        "خزان ماء وقواعد حديد",
        "تصليح وتلحيم عام",
        "عمل مخصص"
    )
}

@Entity(
    tableName = "orders",
    indices = [
        Index("customerId"),
        Index("status"),
        Index("orderDate")
    ]
)
data class Order(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val customerPhone: String,
    val location: String = "",
    val workType: String,
    val description: String = "",
    val measurements: String = "",
    val price: Double = 0.0,
    val paidAmount: Double = 0.0,
    val currency: String = "د.ع",
    val orderDate: String,
    val deliveryDate: String = "",
    val status: String = OrderStatus.IN_PROGRESS,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingAmount: Double
        get() = (price - paidAmount).coerceAtLeast(0.0)
}
