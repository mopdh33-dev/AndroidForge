package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrencyFinancialSummary
import com.example.data.repository.WorkshopRepository
import com.example.ui.components.WorkshopTopBar
import com.example.ui.theme.DebtRed
import com.example.ui.theme.ForgeAmberDark
import com.example.ui.theme.ForgeAmberLight
import com.example.ui.theme.ForgeAmberPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SteelDark
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.WorkshopViewModel

@Composable
fun AccountsPartnershipScreen(
    viewModel: WorkshopViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current

    val summaries by viewModel.financialSummaries.collectAsState()
    val mohammedPct by viewModel.mohammedPercentage.collectAsState()
    val rahenPct by viewModel.rahenPercentage.collectAsState()

    Scaffold(
        topBar = {
            WorkshopTopBar(
                title = "الحسابات والشراكة",
                subtitle = "محمد ($mohammedPct%) & راهن ($rahenPct%)",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    Button(
                        onClick = { viewModel.navigateTo(Screen.SettingsBackup) },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ForgeAmberLight,
                            contentColor = ForgeAmberDark
                        ),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Percent, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تعديل النسبة", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Partnership overview banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(Color(0xFFD1FAE5), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Handshake,
                                    contentDescription = null,
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "شراكة ورشة الحدادة والتلحيم",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "نسبة محمد: ${mohammedPct.toInt()}%  •  نسبة راهن: ${rahenPct.toInt()}%",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Summary for each currency
            items(summaries, key = { it.currency }) { summary ->
                CurrencyPartnershipCard(
                    summary = summary,
                    onShareSummary = {
                        shareSettlementSummary(context, summary)
                    }
                )
            }

            // Explanatory note
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ملاحظة: تعتمد الحسابات على التدفق النقدي الفعلي المحصل (المقبوض نقدًا - المصاريف الفعلية) لتوزيع الأرباح وحساب التسوية العادلة بين الشريكين مع احتساب السحوبات الشخصية.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun CurrencyPartnershipCard(
    summary: CurrencyFinancialSummary,
    onShareSummary: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Currency Title Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ForgeAmberLight,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "عملة الحساب: ${summary.currency}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = ForgeAmberDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                IconButton(onClick = onShareSummary) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "مشاركة التسوية",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Financial Metrics Table
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricRow(title = "إجمالي المبيعات والطلبات:", amount = summary.totalSales, currency = summary.currency)
                MetricRow(title = "إجمالي المقبوض نقداً:", amount = summary.totalPaid, currency = summary.currency, amountColor = ProfitGreen)
                MetricRow(title = "الديون المتبقية عند الزبائن:", amount = summary.totalRemaining, currency = summary.currency, amountColor = if (summary.totalRemaining > 0) DebtRed else ProfitGreen)
                MetricRow(title = "إجمالي المصاريف والمواد:", amount = summary.totalExpenses, currency = summary.currency, amountColor = DebtRed)

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Net Cash Profit
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "صافي الربح الفعلي في الصندوق:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${WorkshopRepository.formatAmount(summary.netCashProfit)} ${summary.currency}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = if (summary.netCashProfit >= 0) ProfitGreen else DebtRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Partner Share Breakdown Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Mohammed Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F3FF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "حساب محمد (${summary.mohammedPercentage.toInt()}%)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF6D28D9)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الحصة: ${WorkshopRepository.formatAmount(summary.mohammedShare)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "السحوبات: ${WorkshopRepository.formatAmount(summary.mohammedWithdrawals)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الرصيد: ${WorkshopRepository.formatAmount(summary.mohammedNetBalance)} ${summary.currency}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (summary.mohammedNetBalance >= 0) ProfitGreen else DebtRed
                        )
                    }
                }

                // Rahen Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "حساب راهن (${summary.rahenPercentage.toInt()}%)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1D4ED8)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الحصة: ${WorkshopRepository.formatAmount(summary.rahenShare)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "السحوبات: ${WorkshopRepository.formatAmount(summary.rahenWithdrawals)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الرصيد: ${WorkshopRepository.formatAmount(summary.rahenNetBalance)} ${summary.currency}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (summary.rahenNetBalance >= 0) ProfitGreen else DebtRed
                        )
                    }
                }
            }

            // Final Settlement Box
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (summary.settlement.settlementAmount > 0) Color(0xFFFEF3C7) else Color(0xFFECFDF5)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settlement_card_${summary.currency}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Balance,
                        contentDescription = null,
                        tint = if (summary.settlement.settlementAmount > 0) ForgeAmberDark else Color(0xFF047857),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "التسوية النهائية للشراكة",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (summary.settlement.settlementAmount > 0) ForgeAmberDark else Color(0xFF047857)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = summary.settlement.explanation,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricRow(
    title: String,
    amount: Double,
    currency: String,
    amountColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "${WorkshopRepository.formatAmount(amount)} $currency",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = amountColor
        )
    }
}

fun shareSettlementSummary(context: Context, summary: CurrencyFinancialSummary) {
    val text = buildString {
        appendLine("📊 كشف حساب وتسوية الورشة (محمد & راهن)")
        appendLine("العملة: ${summary.currency}")
        appendLine("-------------------------------")
        appendLine("إجمالي المبيعات: ${WorkshopRepository.formatAmount(summary.totalSales)} ${summary.currency}")
        appendLine("إجمالي المقبوض: ${WorkshopRepository.formatAmount(summary.totalPaid)} ${summary.currency}")
        appendLine("المتبقي بذمة الزبائن: ${WorkshopRepository.formatAmount(summary.totalRemaining)} ${summary.currency}")
        appendLine("إجمالي المصاريف: ${WorkshopRepository.formatAmount(summary.totalExpenses)} ${summary.currency}")
        appendLine("صافي الربح الفعلي: ${WorkshopRepository.formatAmount(summary.netCashProfit)} ${summary.currency}")
        appendLine("-------------------------------")
        appendLine("👤 حصة محمد (${summary.mohammedPercentage.toInt()}%): ${WorkshopRepository.formatAmount(summary.mohammedShare)} | سحوبات: ${WorkshopRepository.formatAmount(summary.mohammedWithdrawals)} | رصيد: ${WorkshopRepository.formatAmount(summary.mohammedNetBalance)}")
        appendLine("👤 حصة راهن (${summary.rahenPercentage.toInt()}%): ${WorkshopRepository.formatAmount(summary.rahenShare)} | سحوبات: ${WorkshopRepository.formatAmount(summary.rahenWithdrawals)} | رصيد: ${WorkshopRepository.formatAmount(summary.rahenNetBalance)}")
        appendLine("-------------------------------")
        appendLine("⚖️ نتيجة التسوية: ${summary.settlement.explanation}")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة تسوية الحسابات"))
}
