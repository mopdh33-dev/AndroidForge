package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PartnerWithdrawal
import kotlinx.coroutines.flow.Flow

@Dao
interface PartnerWithdrawalDao {
    @Query("SELECT * FROM partner_withdrawals ORDER BY date DESC, createdAt DESC")
    fun getAllWithdrawals(): Flow<List<PartnerWithdrawal>>

    @Query("SELECT * FROM partner_withdrawals WHERE partnerName = :partnerName ORDER BY date DESC")
    fun getWithdrawalsByPartner(partnerName: String): Flow<List<PartnerWithdrawal>>

    @Query("SELECT * FROM partner_withdrawals WHERE date LIKE :yearMonthPrefix || '%' ORDER BY date DESC")
    fun getWithdrawalsByMonth(yearMonthPrefix: String): Flow<List<PartnerWithdrawal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWithdrawal(withdrawal: PartnerWithdrawal): Long

    @Update
    suspend fun updateWithdrawal(withdrawal: PartnerWithdrawal)

    @Delete
    suspend fun deleteWithdrawal(withdrawal: PartnerWithdrawal)

    @Query("DELETE FROM partner_withdrawals WHERE id = :id")
    suspend fun deleteWithdrawalById(id: Long)
}
