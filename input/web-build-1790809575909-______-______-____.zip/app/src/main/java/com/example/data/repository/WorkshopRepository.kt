package com.example.data.repository

import com.example.data.local.WorkshopDatabase
import com.example.data.model.CurrencyFinancialSummary
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Order
import com.example.data.model.OrderModification
import com.example.data.model.OrderWithModifications
import com.example.data.model.PartnerSettlement
import com.example.data.model.PartnerWithdrawal
import com.example.data.model.Partners
import com.example.data.model.SettingKeys
import com.example.data.model.WithdrawalSources
import com.example.data.model.WorkshopSetting
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WorkshopRepository(private val database: WorkshopDatabase) {

    private val customerDao = database.customerDao()
    private val orderDao = database.orderDao()
    private val modificationDao = database.orderModificationDao()
    private val expenseDao = database.expenseDao()
    private val withdrawalDao = database.partnerWithdrawalDao()
    private val settingDao = database.workshopSettingDao()

    // Customers
    fun getAllCustomers(): Flow<List<Customer>> = customerDao.getAllCustomers()
    fun getCustomerById(id: Long): Flow<Customer?> = customerDao.getCustomerById(id)
    suspend fun getCustomerByIdDirect(id: Long): Customer? = customerDao.getCustomerByIdDirect(id)
    fun searchCustomers(q: String): Flow<List<Customer>> = customerDao.searchCustomers(q)
    suspend fun insertCustomer(customer: Customer): Long = customerDao.insertCustomer(customer)
    suspend fun updateCustomer(customer: Customer) = customerDao.updateCustomer(customer)
    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    // Orders
    fun getAllOrders(): Flow<List<Order>> = orderDao.getAllOrders()
    fun getOrderById(id: Long): Flow<Order?> = orderDao.getOrderById(id)
    suspend fun getOrderByIdDirect(id: Long): Order? = orderDao.getOrderByIdDirect(id)
    fun getOrdersByCustomerId(customerId: Long): Flow<List<Order>> = orderDao.getOrdersByCustomerId(customerId)
    fun searchOrders(q: String): Flow<List<Order>> = orderDao.searchOrders(q)
    suspend fun insertOrder(order: Order): Long = orderDao.insertOrder(order)
    suspend fun updateOrder(order: Order) = orderDao.updateOrder(order)
    suspend fun deleteOrder(order: Order) {
        modificationDao.deleteModificationsByOrderId(order.id)
        orderDao.deleteOrder(order)
    }
    suspend fun deleteOrderById(id: Long) {
        modificationDao.deleteModificationsByOrderId(id)
        orderDao.deleteOrderById(id)
    }
    suspend fun updateOrderPaidAmount(orderId: Long, newPaid: Double) =
        orderDao.updateOrderPaidAmount(orderId, newPaid)
    suspend fun updateOrderStatus(orderId: Long, status: String) =
        orderDao.updateOrderStatus(orderId, status)

    // Modifications
    fun getModificationsForOrder(orderId: Long): Flow<List<OrderModification>> =
        modificationDao.getModificationsForOrder(orderId)
    fun getAllModifications(): Flow<List<OrderModification>> = modificationDao.getAllModifications()
    suspend fun insertModification(modification: OrderModification): Long =
        modificationDao.insertModification(modification)
    suspend fun deleteModification(modification: OrderModification) =
        modificationDao.deleteModification(modification)
    suspend fun deleteModificationById(id: Long) = modificationDao.deleteModificationById(id)

    // Combined Order With Modifications
    fun getOrderWithModifications(orderId: Long): Flow<OrderWithModifications?> {
        return combine(
            orderDao.getOrderById(orderId),
            modificationDao.getModificationsForOrder(orderId)
        ) { order, mods ->
            order?.let { OrderWithModifications(it, mods) }
        }
    }

    fun getAllOrdersWithModifications(): Flow<List<OrderWithModifications>> {
        return combine(
            orderDao.getAllOrders(),
            modificationDao.getAllModifications()
        ) { orders, mods ->
            val modsByOrder = mods.groupBy { it.orderId }
            orders.map { order ->
                OrderWithModifications(order, modsByOrder[order.id] ?: emptyList())
            }
        }
    }

    // Expenses
    fun getAllExpenses(): Flow<List<Expense>> = expenseDao.getAllExpenses()
    fun searchExpenses(q: String): Flow<List<Expense>> = expenseDao.searchExpenses(q)
    suspend fun insertExpense(expense: Expense): Long = expenseDao.insertExpense(expense)
    suspend fun updateExpense(expense: Expense) = expenseDao.updateExpense(expense)
    suspend fun deleteExpense(expense: Expense) = expenseDao.deleteExpense(expense)
    suspend fun deleteExpenseById(id: Long) = expenseDao.deleteExpenseById(id)

    // Partner Withdrawals
    fun getAllWithdrawals(): Flow<List<PartnerWithdrawal>> = withdrawalDao.getAllWithdrawals()
    fun getWithdrawalsByPartner(partnerName: String): Flow<List<PartnerWithdrawal>> =
        withdrawalDao.getWithdrawalsByPartner(partnerName)
    suspend fun insertWithdrawal(withdrawal: PartnerWithdrawal): Long =
        withdrawalDao.insertWithdrawal(withdrawal)
    suspend fun updateWithdrawal(withdrawal: PartnerWithdrawal) =
        withdrawalDao.updateWithdrawal(withdrawal)
    suspend fun deleteWithdrawal(withdrawal: PartnerWithdrawal) =
        withdrawalDao.deleteWithdrawal(withdrawal)

    // Settings
    fun getAllSettings(): Flow<List<WorkshopSetting>> = settingDao.getAllSettings()
    fun getSetting(key: String, defaultValue: String): Flow<String> =
        settingDao.getSetting(key).map { it?.value ?: defaultValue }
    suspend fun getSettingDirect(key: String, defaultValue: String): String =
        settingDao.getSettingDirect(key)?.value ?: defaultValue
    suspend fun setSetting(key: String, value: String) =
        settingDao.setSettingValue(key, value)

    // Financial Calculation Helper (Per Currency - No Currency Mixing!)
    companion object {
        fun calculateSummaries(
            ordersWithMods: List<OrderWithModifications>,
            expenses: List<Expense>,
            withdrawals: List<PartnerWithdrawal>,
            mohammedPct: Double,
            rahenPct: Double
        ): List<CurrencyFinancialSummary> {
            val allCurrencies = (
                ordersWithMods.map { it.order.currency } +
                expenses.map { it.currency } +
                withdrawals.map { it.currency }
            ).filter { it.isNotBlank() }.distinct()

            val currencies = if (allCurrencies.isEmpty()) listOf("د.ع") else allCurrencies

            return currencies.map { cur ->
                val currencyOrders = ordersWithMods.filter { it.order.currency == cur }
                val currencyExpenses = expenses.filter { it.currency == cur }
                val currencyWithdrawals = withdrawals.filter { it.currency == cur }

                val totalSales = currencyOrders.sumOf { it.totalPrice }
                val totalPaid = currencyOrders.sumOf { it.totalPaid }
                val totalRemaining = currencyOrders.sumOf { it.totalRemaining }
                val totalExpenses = currencyExpenses.sumOf { it.amount }

                val netCashProfit = totalPaid - totalExpenses
                val netTotalProfit = totalSales - totalExpenses

                // Base profit for partnership calculations: net cash collected or total profit
                // In standard workshop practice, partners divide actual cash collected minus expenses
                val baseProfit = netCashProfit

                val mShare = (baseProfit * (mohammedPct / 100.0)).coerceAtLeast(0.0)
                val rShare = (baseProfit * (rahenPct / 100.0)).coerceAtLeast(0.0)

                // Partner withdrawals from partnership account
                val mWithdrawals = currencyWithdrawals
                    .filter { it.partnerName == Partners.MOHAMMED }
                    .sumOf { it.amount }
                val rWithdrawals = currencyWithdrawals
                    .filter { it.partnerName == Partners.RAHEN }
                    .sumOf { it.amount }

                // Net balance per partner (Share - Withdrawals)
                val mNetBalance = mShare - mWithdrawals
                val rNetBalance = rShare - rWithdrawals

                // Settlement calculation
                // If Mohammed has a negative net balance (withdrew more than share), he owes to the pool/partner
                // If Rahen withdrew less than share, he is owed money
                val settlement = calculateSettlement(
                    mNetBalance = mNetBalance,
                    rNetBalance = rNetBalance,
                    currency = cur,
                    mohammedPct = mohammedPct,
                    rahenPct = rahenPct,
                    withdrawals = currencyWithdrawals
                )

                CurrencyFinancialSummary(
                    currency = cur,
                    totalSales = totalSales,
                    totalPaid = totalPaid,
                    totalRemaining = totalRemaining,
                    totalExpenses = totalExpenses,
                    netCashProfit = netCashProfit,
                    netTotalProfit = netTotalProfit,
                    mohammedPercentage = mohammedPct,
                    rahenPercentage = rahenPct,
                    mohammedShare = mShare,
                    rahenShare = rShare,
                    mohammedWithdrawals = mWithdrawals,
                    rahenWithdrawals = rWithdrawals,
                    mohammedNetBalance = mNetBalance,
                    rahenNetBalance = rNetBalance,
                    settlement = settlement
                )
            }
        }

        private fun calculateSettlement(
            mNetBalance: Double,
            rNetBalance: Double,
            currency: String,
            mohammedPct: Double,
            rahenPct: Double,
            withdrawals: List<PartnerWithdrawal>
        ): PartnerSettlement {
            // Direct personal loans between partners
            val mohammedTookFromRahen = withdrawals
                .filter { it.partnerName == Partners.MOHAMMED && it.fromSource == WithdrawalSources.OTHER_PARTNER_FUNDS }
                .sumOf { it.amount }
            val rahenTookFromMohammed = withdrawals
                .filter { it.partnerName == Partners.RAHEN && it.fromSource == WithdrawalSources.OTHER_PARTNER_FUNDS }
                .sumOf { it.amount }

            val directDebt = mohammedTookFromRahen - rahenTookFromMohammed

            // Difference between net balances
            val diff = (rNetBalance - mNetBalance) / 2.0 + directDebt

            return when {
                kotlin.math.abs(diff) < 0.01 -> {
                    PartnerSettlement(
                        debtorPartner = null,
                        creditorPartner = null,
                        settlementAmount = 0.0,
                        explanation = "الحسابات متوازنة تماماً بين الشريكين"
                    )
                }
                diff > 0 -> {
                    // Mohammed took more or Rahen is owed more -> Mohammed pays Rahen
                    PartnerSettlement(
                        debtorPartner = Partners.MOHAMMED,
                        creditorPartner = Partners.RAHEN,
                        settlementAmount = diff,
                        explanation = "محمد يدفع لراهن مبلغ ${formatAmount(diff)} $currency لتسوية الأرباح والسحوبات"
                    )
                }
                else -> {
                    val amount = kotlin.math.abs(diff)
                    PartnerSettlement(
                        debtorPartner = Partners.RAHEN,
                        creditorPartner = Partners.MOHAMMED,
                        settlementAmount = amount,
                        explanation = "راهن يدفع لمحمد مبلغ ${formatAmount(amount)} $currency لتسوية الأرباح والسحوبات"
                    )
                }
            }
        }

        fun formatAmount(amount: Double): String {
            return if (amount % 1.0 == 0.0) {
                String.format(Locale.US, "%,.0f", amount)
            } else {
                String.format(Locale.US, "%,.2f", amount)
            }
        }
    }

    // Backup Export to JSON String
    suspend fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("timestamp", System.currentTimeMillis())
        root.put("exportDate", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))

        // Settings
        val settingsObj = JSONObject()
        settingsObj.put(SettingKeys.MOHAMMED_PERCENTAGE, getSettingDirect(SettingKeys.MOHAMMED_PERCENTAGE, "50"))
        settingsObj.put(SettingKeys.RAHEN_PERCENTAGE, getSettingDirect(SettingKeys.RAHEN_PERCENTAGE, "50"))
        settingsObj.put(SettingKeys.DEFAULT_CURRENCY, getSettingDirect(SettingKeys.DEFAULT_CURRENCY, "د.ع"))
        settingsObj.put(SettingKeys.WORKSHOP_NAME, getSettingDirect(SettingKeys.WORKSHOP_NAME, "ورشة محمد & راهن للحدادة والأبواب"))
        root.put("settings", settingsObj)

        return root.toString(2)
    }

    // Prepopulate realistic initial sample data for workshop
    suspend fun seedSampleDataIfNeeded() {
        val existingCustomers = customerDao.getCustomerByIdDirect(1)
        if (existingCustomers == null) {
            val c1Id = insertCustomer(
                Customer(
                    name = "أبو وسام (مقاولات)",
                    phone = "07701234567",
                    location = "حي الجامعة، شارع 14",
                    notes = "زبون دائم للمشاريع والمقاولات"
                )
            )
            val c2Id = insertCustomer(
                Customer(
                    name = "حاج كريم العلي",
                    phone = "07809876543",
                    location = "المنصور، قرب المسجد",
                    notes = "بناء منزل جديد"
                )
            )
            val c3Id = insertCustomer(
                Customer(
                    name = "مهندس علي التميمي",
                    phone = "07505554321",
                    location = "شارع الكرادة",
                    notes = "مكتب استشارات هندسية"
                )
            )

            val order1Id = insertOrder(
                Order(
                    customerId = c1Id,
                    customerName = "أبو وسام (مقاولات)",
                    customerPhone = "07701234567",
                    location = "حي الجامعة، شارع 14",
                    workType = "باب رئيسي حديد",
                    description = "باب خارجي ضلفتين نقشة ليزر حديثة مع إطار زاوية مقوى ومفصلات إيطالية",
                    measurements = "2.80 م ارتفاع × 2.40 م عرض",
                    price = 850000.0,
                    paidAmount = 500000.0,
                    currency = "د.ع",
                    orderDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                    deliveryDate = "خلال 10 أيام",
                    notes = "الصبغ أسود مطفي مع تذهيب خفيف"
                )
            )

            // Additional work for order 1
            insertModification(
                OrderModification(
                    orderId = order1Id,
                    title = "إضافة كوالين أمان إيطالية إضافية + يدات مذهبة",
                    description = "طلب الزبون زيادة عدد الكوالين إلى 2",
                    additionalPrice = 75000.0,
                    additionalPaid = 75000.0,
                    date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                )
            )

            val order2Id = insertOrder(
                Order(
                    customerId = c2Id,
                    customerName = "حاج كريم العلي",
                    customerPhone = "07809876543",
                    location = "المنصور، قرب المسجد",
                    workType = "شبابيك حماية",
                    description = "عدد 6 شبابيك حماية حديد مبروم 14 ملم بتصميم إسلامي مزخرف",
                    measurements = "1.50 × 1.20 م (6 قطع)",
                    price = 600000.0,
                    paidAmount = 300000.0,
                    currency = "د.ع",
                    orderDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                    deliveryDate = "الأسبوع القادم",
                    notes = "تشمل الرش بالأساس المانع للصدأ"
                )
            )

            // Expenses
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            insertExpense(
                Expense(
                    category = "حديد",
                    amount = 350000.0,
                    currency = "د.ع",
                    date = todayStr,
                    note = "شراء بواريا وتيوبات حديد 4×8 ومبروم 14"
                )
            )
            insertExpense(
                Expense(
                    category = "أقراص قص",
                    amount = 35000.0,
                    currency = "د.ع",
                    date = todayStr,
                    note = "كرتونة أقراص قص 14 إنج ومجلخ"
                )
            )
            insertExpense(
                Expense(
                    category = "أسلاك/أقطاب لحام",
                    amount = 45000.0,
                    currency = "د.ع",
                    date = todayStr,
                    note = "باكيت سيم لحام 6013 مقاس 3.2 ملم"
                )
            )
            insertExpense(
                Expense(
                    category = "نقل",
                    amount = 25000.0,
                    currency = "د.ع",
                    date = todayStr,
                    note = "أجرة سيارة حمل نقل حديد من المعرض للورشة"
                )
            )

            // Partner withdrawals
            insertWithdrawal(
                PartnerWithdrawal(
                    partnerName = Partners.MOHAMMED,
                    amount = 50000.0,
                    currency = "د.ع",
                    date = todayStr,
                    reason = "مصروف شخصي من الصندوق",
                    fromSource = WithdrawalSources.PARTNERSHIP_FUNDS
                )
            )

            // Initialize default settings
            setSetting(SettingKeys.MOHAMMED_PERCENTAGE, "50")
            setSetting(SettingKeys.RAHEN_PERCENTAGE, "50")
            setSetting(SettingKeys.DEFAULT_CURRENCY, "د.ع")
            setSetting(SettingKeys.WORKSHOP_NAME, "ورشة محمد & راهن للحدادة والأبواب")
        }
    }
}
