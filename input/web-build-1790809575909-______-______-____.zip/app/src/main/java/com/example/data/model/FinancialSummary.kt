package com.example.data.model

data class OrderWithModifications(
    val order: Order,
    val modifications: List<OrderModification> = emptyList()
) {
    val totalPrice: Double
        get() = order.price + modifications.sumOf { it.additionalPrice }

    val totalPaid: Double
        get() = order.paidAmount + modifications.sumOf { it.additionalPaid }

    val totalRemaining: Double
        get() = (totalPrice - totalPaid).coerceAtLeast(0.0)

    val hasModifications: Boolean
        get() = modifications.isNotEmpty()
}

data class CustomerWithStats(
    val customer: Customer,
    val ordersCount: Int,
    val totalOrdersAmount: Double,
    val totalPaid: Double,
    val totalRemaining: Double,
    val currency: String
)

data class PartnerSettlement(
    val debtorPartner: String?,    // من عليه أن يدفع
    val creditorPartner: String?,  // من يستحق أن يستلم
    val settlementAmount: Double,  // مبلغ التسوية
    val explanation: String        // شرح توضيحي بسيط
)

data class CurrencyFinancialSummary(
    val currency: String,
    val totalSales: Double,            // إجمالي المبيعات (مع التعديلات)
    val totalPaid: Double,             // إجمالي المقبوض نقدًا
    val totalRemaining: Double,        // المتبقي بذمة الزبائن
    val totalExpenses: Double,         // إجمالي المصاريف
    val netCashProfit: Double,         // صافي الربح النقدي الفعلي (المقبوض - المصاريف)
    val netTotalProfit: Double,        // صافي الربح المحسوب الإجمالي (المبيعات - المصاريف)
    val mohammedPercentage: Double,    // نسبة محمد %
    val rahenPercentage: Double,       // نسبة راهن %
    val mohammedShare: Double,         // نصيب محمد من صافي الربح
    val rahenShare: Double,            // نصيب راهن من صافي الربح
    val mohammedWithdrawals: Double,   // سحوبات محمد
    val rahenWithdrawals: Double,      // سحوبات راهن
    val mohammedNetBalance: Double,    // رصيد محمد المتبقي (نصيبه - سحوباته)
    val rahenNetBalance: Double,       // رصيد راهن المتبقي (نصيبه - سحوباته)
    val settlement: PartnerSettlement  // التسوية النهائية
)
