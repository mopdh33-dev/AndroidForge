package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrencyFinancialSummary
import com.example.data.repository.WorkshopRepository
import com.example.ui.components.WorkshopTopBar
import com.example.ui.theme.DebtRed
import com.example.ui.theme.ForgeAmberDark
import com.example.ui.theme.ForgeAmberLight
import com.example.ui.theme.ForgeAmberPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SteelDark
import com.example.ui.viewmodel.WorkshopViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun MonthlyReportsScreen(
    viewModel: WorkshopViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current

    val selectedMonth by viewModel.selectedMonth.collectAsState()
    val monthlySummaries by viewModel.monthlyFinancialSummaries.collectAsState()
    val mohammedPct by viewModel.mohammedPercentage.collectAsState()
    val rahenPct by viewModel.rahenPercentage.collectAsState()

    // Helper to advance / regress month
    fun adjustMonth(offset: Int) {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val cal = Calendar.getInstance()
        try {
            val date = sdf.parse(selectedMonth)
            if (date != null) cal.time = date
        } catch (_: Exception) {}
        cal.add(Calendar.MONTH, offset)
        viewModel.selectMonth(sdf.format(cal.time))
    }

    val displayMonthArabic = try {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val date = sdf.parse(selectedMonth)
        if (date != null) {
            SimpleDateFormat("MMMM yyyy", Locale("ar")).format(date)
        } else selectedMonth
    } catch (_: Exception) {
        selectedMonth
    }

    Scaffold(
        topBar = {
            WorkshopTopBar(
                title = "التقارير الشهرية",
                subtitle = "تقرير شهر $displayMonthArabic",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Month Selector Header Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { adjustMonth(-1) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "الشهر السابق"
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = displayMonthArabic,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(onClick = { adjustMonth(1) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "الشهر التالي"
                            )
                        }
                    }
                }
            }

            if (monthlySummaries.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد أي حركات مالية مسجلة لشهر $displayMonthArabic",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(monthlySummaries, key = { it.currency }) { summary ->
                    MonthlySummaryCard(
                        monthName = displayMonthArabic,
                        summary = summary,
                        onShare = { shareMonthlyReport(context, displayMonthArabic, summary) }
                    )
                }
            }
        }
    }
}

@Composable
fun MonthlySummaryCard(
    monthName: String,
    summary: CurrencyFinancialSummary,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Currency and Share Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ForgeAmberLight,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "كشف عملة: ${summary.currency}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = ForgeAmberDark,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Button(
                    onClick = onShare,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7), contentColor = Color.White),
                    modifier = Modifier.testTag("share_month_report_${summary.currency}")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة التقرير", style = MaterialTheme.typography.labelSmall)
                }
            }

            HorizontalDivider()

            // Financial items required by user brief:
            // 1. إجمالي المبيعات
            MetricRow(title = "1. إجمالي المبيعات والطلبات:", amount = summary.totalSales, currency = summary.currency)

            // 2. المدفوع
            MetricRow(title = "2. المبلغ المدفوع (المقبوض):", amount = summary.totalPaid, currency = summary.currency, amountColor = ProfitGreen)

            // 3. المتبقي
            MetricRow(title = "3. المبلغ المتبقي بذمة الزبائن:", amount = summary.totalRemaining, currency = summary.currency, amountColor = if (summary.totalRemaining > 0) DebtRed else ProfitGreen)

            // 4. إجمالي المصاريف
            MetricRow(title = "4. إجمالي مصاريف الشهر:", amount = summary.totalExpenses, currency = summary.currency, amountColor = DebtRed)

            // 5. صافي الربح / الخسارة
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (summary.netCashProfit >= 0) Color(0xFFF0FDF4) else Color(0xFFFEF2F2),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "5. صافي الربح / الخسارة الفعلي:",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${WorkshopRepository.formatAmount(summary.netCashProfit)} ${summary.currency}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = if (summary.netCashProfit >= 0) ProfitGreen else DebtRed
                )
            }

            // 6. نصيب محمد
            MetricRow(
                title = "6. نصيب محمد (${summary.mohammedPercentage.toInt()}%):",
                amount = summary.mohammedShare,
                currency = summary.currency,
                amountColor = Color(0xFF6D28D9)
            )

            // 7. نصيب راهن
            MetricRow(
                title = "7. نصيب راهن (${summary.rahenPercentage.toInt()}%):",
                amount = summary.rahenShare,
                currency = summary.currency,
                amountColor = Color(0xFF1D4ED8)
            )

            // 8. السحوبات
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "8. سحوبات الشركاء خلال الشهر:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "محمد: ${WorkshopRepository.formatAmount(summary.mohammedWithdrawals)} | راهن: ${WorkshopRepository.formatAmount(summary.rahenWithdrawals)} ${summary.currency}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }

            HorizontalDivider()

            // 9. التسوية النهائية
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (summary.settlement.settlementAmount > 0) Color(0xFFFEF3C7) else Color(0xFFECFDF5)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "9. التسوية النهائية للشهر:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (summary.settlement.settlementAmount > 0) ForgeAmberDark else Color(0xFF047857)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = summary.settlement.explanation,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

fun shareMonthlyReport(context: Context, monthName: String, summary: CurrencyFinancialSummary) {
    val reportText = buildString {
        appendLine("📑 تقرير شهر $monthName - ورشة محمد & راهن للحدادة")
        appendLine("العملة: ${summary.currency}")
        appendLine("===============================")
        appendLine("1. إجمالي المبيعات: ${WorkshopRepository.formatAmount(summary.totalSales)} ${summary.currency}")
        appendLine("2. المبلغ المدفوع: ${WorkshopRepository.formatAmount(summary.totalPaid)} ${summary.currency}")
        appendLine("3. المبلغ المتبقي: ${WorkshopRepository.formatAmount(summary.totalRemaining)} ${summary.currency}")
        appendLine("4. إجمالي المصاريف: ${WorkshopRepository.formatAmount(summary.totalExpenses)} ${summary.currency}")
        appendLine("5. صافي الربح الفعلي: ${WorkshopRepository.formatAmount(summary.netCashProfit)} ${summary.currency}")
        appendLine("-------------------------------")
        appendLine("6. نصيب محمد (${summary.mohammedPercentage.toInt()}%): ${WorkshopRepository.formatAmount(summary.mohammedShare)} ${summary.currency}")
        appendLine("7. نصيب راهن (${summary.rahenPercentage.toInt()}%): ${WorkshopRepository.formatAmount(summary.rahenShare)} ${summary.currency}")
        appendLine("8. السحوبات: محمد (${WorkshopRepository.formatAmount(summary.mohammedWithdrawals)}) - راهن (${WorkshopRepository.formatAmount(summary.rahenWithdrawals)})")
        appendLine("-------------------------------")
        appendLine("9. التسوية النهائية: ${summary.settlement.explanation}")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, reportText)
    }
    context.startActivity(Intent.createChooser(intent, "إرسال تقرير شهر $monthName"))
}
