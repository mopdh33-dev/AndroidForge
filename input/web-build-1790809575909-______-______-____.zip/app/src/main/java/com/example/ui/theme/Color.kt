package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary industrial forge amber & steel slate palette
val ForgeAmberPrimary = Color(0xFFD97706)
val ForgeAmberDark = Color(0xFFB45309)
val ForgeAmberLight = Color(0xFFFDE68A)

val SteelDark = Color(0xFF0F172A)
val SteelSlate = Color(0xFF1E293B)
val SteelBorder = Color(0xFF334155)
val SteelSurface = Color(0xFF1E293B)

val IndustrialLightBg = Color(0xFFF8FAFC)
val IndustrialCardLight = Color(0xFFFFFFFF)
val IndustrialCardBorder = Color(0xFFE2E8F0)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

// Financial & Status colors
val ProfitGreen = Color(0xFF15803D)
val ProfitGreenLight = Color(0xFFDCFCE7)

val DebtRed = Color(0xFFDC2626)
val DebtRedLight = Color(0xFFFEE2E2)

val BlueStatus = Color(0xFF2563EB)
val BlueStatusLight = Color(0xFFDBEAFE)

val OrangeStatus = Color(0xFFEA580C)
val OrangeStatusLight = Color(0xFFFFEDD5)
