package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object ExpenseCategories {
    const val IRON = "حديد"
    const val RENT = "إيجار"
    const val CUTTING_DISCS = "أقراص قص"
    const val WELDING_WIRES = "أسلاك/أقطاب لحام"
    const val TOOLS = "أدوات"
    const val TRANSPORTATION = "نقل"
    const val INSTALLATION = "تركيب"
    const val MAINTENANCE = "صيانة"
    const val OTHER = "مصاريف أخرى"

    val allCategories = listOf(
        IRON,
        RENT,
        CUTTING_DISCS,
        WELDING_WIRES,
        TOOLS,
        TRANSPORTATION,
        INSTALLATION,
        MAINTENANCE,
        OTHER
    )
}

@Entity(
    tableName = "expenses",
    indices = [
        Index("category"),
        Index("date")
    ]
)
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String,
    val amount: Double,
    val currency: String = "د.ع",
    val date: String,
    val note: String = "",
    val relatedOrderId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
