package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ForgeAmberLight,
    onPrimary = SteelDark,
    primaryContainer = ForgeAmberDark,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFF94A3B8),
    onSecondary = SteelDark,
    secondaryContainer = SteelBorder,
    onSecondaryContainer = Color.White,
    background = SteelDark,
    onBackground = TextPrimaryDark,
    surface = SteelSlate,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFF242F42),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = SteelBorder
)

private val LightColorScheme = lightColorScheme(
    primary = ForgeAmberPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = ForgeAmberDark,
    secondary = SteelSlate,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF1F5F9),
    onSecondaryContainer = SteelSlate,
    background = IndustrialLightBg,
    onBackground = TextPrimaryLight,
    surface = IndustrialCardLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = TextSecondaryLight,
    outline = IndustrialCardBorder
)

@Composable
fun WorkshopTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep workshop brand theme consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
