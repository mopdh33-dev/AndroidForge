package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.OrderModification
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderModificationDao {
    @Query("SELECT * FROM order_modifications WHERE orderId = :orderId ORDER BY createdAt ASC")
    fun getModificationsForOrder(orderId: Long): Flow<List<OrderModification>>

    @Query("SELECT * FROM order_modifications WHERE orderId = :orderId ORDER BY createdAt ASC")
    suspend fun getModificationsForOrderDirect(orderId: Long): List<OrderModification>

    @Query("SELECT * FROM order_modifications ORDER BY createdAt DESC")
    fun getAllModifications(): Flow<List<OrderModification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModification(modification: OrderModification): Long

    @Update
    suspend fun updateModification(modification: OrderModification)

    @Delete
    suspend fun deleteModification(modification: OrderModification)

    @Query("DELETE FROM order_modifications WHERE id = :id")
    suspend fun deleteModificationById(id: Long)

    @Query("DELETE FROM order_modifications WHERE orderId = :orderId")
    suspend fun deleteModificationsByOrderId(orderId: Long)
}
