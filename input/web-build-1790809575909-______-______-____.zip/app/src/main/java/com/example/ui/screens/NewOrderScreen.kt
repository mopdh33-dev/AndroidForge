package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderStatus
import com.example.data.model.WorkTypes
import com.example.data.repository.WorkshopRepository
import com.example.ui.components.WorkshopTopBar
import com.example.ui.theme.DebtRed
import com.example.ui.theme.ForgeAmberDark
import com.example.ui.theme.ForgeAmberPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SteelDark
import com.example.ui.viewmodel.WorkshopViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NewOrderScreen(
    viewModel: WorkshopViewModel,
    prefilledCustomerId: Long? = null,
    editingOrderId: Long? = null,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val customers by viewModel.customers.collectAsState()
    val orders by viewModel.ordersWithMods.collectAsState()
    val defaultCurrency by viewModel.defaultCurrency.collectAsState()

    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var selectedCustomerId by remember { mutableStateOf<Long?>(prefilledCustomerId) }

    var workType by remember { mutableStateOf(WorkTypes.commonTypes.first()) }
    var customWorkType by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var measurements by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var paidText by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf(defaultCurrency) }
    var orderDate by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var deliveryDate by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(OrderStatus.IN_PROGRESS) }
    var notes by remember { mutableStateOf("") }

    // If prefilled customer
    LaunchedEffect(prefilledCustomerId, customers) {
        if (prefilledCustomerId != null) {
            val c = customers.firstOrNull { it.id == prefilledCustomerId }
            if (c != null) {
                customerName = c.name
                customerPhone = c.phone
                location = c.location
                selectedCustomerId = c.id
            }
        }
    }

    // If editing existing order
    LaunchedEffect(editingOrderId, orders) {
        if (editingOrderId != null) {
            val ord = orders.firstOrNull { it.order.id == editingOrderId }?.order
            if (ord != null) {
                selectedCustomerId = ord.customerId
                customerName = ord.customerName
                customerPhone = ord.customerPhone
                location = ord.location
                if (WorkTypes.commonTypes.contains(ord.workType)) {
                    workType = ord.workType
                } else {
                    workType = "عمل مخصص"
                    customWorkType = ord.workType
                }
                description = ord.description
                measurements = ord.measurements
                priceText = if (ord.price > 0) ord.price.toInt().toString() else ""
                paidText = if (ord.paidAmount > 0) ord.paidAmount.toInt().toString() else ""
                currency = ord.currency
                orderDate = ord.orderDate
                deliveryDate = ord.deliveryDate
                status = ord.status
                notes = ord.notes
            }
        }
    }

    val price = priceText.toDoubleOrNull() ?: 0.0
    val paid = paidText.toDoubleOrNull() ?: 0.0
    val remaining = (price - paid).coerceAtLeast(0.0)

    val finalWorkType = if (workType == "عمل مخصص" && customWorkType.isNotBlank()) customWorkType else workType

    var customerDropdownExpanded by remember { mutableStateOf(false) }
    var currencyDropdownExpanded by remember { mutableStateOf(false) }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    val currenciesList = listOf("د.ع", "$", "ر.س", "ل.س", "ج.م")

    Scaffold(
        topBar = {
            WorkshopTopBar(
                title = if (editingOrderId == null) "إضافة طلب جديد" else "تعديل الطلب",
                subtitle = if (customerName.isNotBlank()) "الزبون: $customerName" else null,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.saveOrder(
                                orderId = editingOrderId ?: 0L,
                                customerId = selectedCustomerId,
                                customerName = customerName,
                                customerPhone = customerPhone,
                                location = location,
                                workType = finalWorkType,
                                description = description,
                                measurements = measurements,
                                price = price,
                                paidAmount = paid,
                                currency = currency,
                                orderDate = orderDate,
                                deliveryDate = deliveryDate,
                                status = status,
                                notes = notes
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ForgeAmberPrimary,
                            contentColor = SteelDark
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_order_button")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (editingOrderId == null) "حفظ الطلب الجديد" else "حفظ تعديلات الطلب",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Customer Section Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "بيانات الزبون",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (selectedCustomerId != null) {
                            Surface(
                                color = Color(0xFFDBEAFE),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "عميل حالي",
                                    color = Color(0xFF1D4ED8),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Existing customer selector
                    if (customers.isNotEmpty() && editingOrderId == null) {
                        ExposedDropdownMenuBox(
                            expanded = customerDropdownExpanded,
                            onExpandedChange = { customerDropdownExpanded = !customerDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = if (selectedCustomerId != null) customerName else "اختر من قائمة العملاء الحاليين (أو اكتب زبون جديد)",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerDropdownExpanded) },
                                leadingIcon = { Icon(imageVector = Icons.Default.Person, contentDescription = null) },
                                label = { Text("اختيار عميل مسجل مسبقاً") },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = customerDropdownExpanded,
                                onDismissRequest = { customerDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("➕ عميل جديد (كتابة بيانات جديدة)", fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        selectedCustomerId = null
                                        customerName = ""
                                        customerPhone = ""
                                        location = ""
                                        customerDropdownExpanded = false
                                    }
                                )
                                customers.forEach { c ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(c.name, fontWeight = FontWeight.Bold)
                                                if (c.phone.isNotBlank()) {
                                                    Text(c.phone, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                }
                                            }
                                        },
                                        onClick = {
                                            selectedCustomerId = c.id
                                            customerName = c.name
                                            customerPhone = c.phone
                                            location = c.location
                                            customerDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("اسم الزبون (اختياري)") },
                        placeholder = { Text("مثال: أبو أحمد، المهندس سامر") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_customer_name"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("رقم الهاتف") },
                        placeholder = { Text("0770XXXXXXX") },
                        leadingIcon = { Icon(imageVector = Icons.Default.Phone, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_customer_phone"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("الموقع / العنوان") },
                        placeholder = { Text("المنطقة، الشارع، رقم الدار") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // Work Specs Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "تفاصيل العمل والحديد",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "نوع العمل المطلوب:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WorkTypes.commonTypes.forEach { type ->
                            FilterChip(
                                selected = workType == type,
                                onClick = { workType = type },
                                label = { Text(type) }
                            )
                        }
                    }

                    if (workType == "عمل مخصص") {
                        OutlinedTextField(
                            value = customWorkType,
                            onValueChange = { customWorkType = it },
                            label = { Text("حدد نوع العمل المخصص") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = measurements,
                        onValueChange = { measurements = it },
                        label = { Text("المقاسات (الارتفاع × العرض)") },
                        placeholder = { Text("مثال: 2.20 م ارتفاع × 1.10 م عرض") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_measurements"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("وصف العمل ومواصفات الحديد") },
                        placeholder = { Text("سماكة الصاج، نوع التيوب، النقشة، اللون...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_description"),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            // Financial & Pricing Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "الأسعار والدفعات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Currency Selector Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "عملة الطلب:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            currenciesList.forEach { cur ->
                                FilterChip(
                                    selected = currency == cur,
                                    onClick = { currency = cur },
                                    label = { Text(cur, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it },
                            label = { Text("السعر الإجمالي ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_order_price"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = paidText,
                            onValueChange = { paidText = it },
                            label = { Text("المدفوع / العربون ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_order_paid"),
                            singleLine = true
                        )
                    }

                    // Auto-calculated Remaining Banner
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (remaining > 0) Color(0xFFFEF2F2) else Color(0xFFF0FDF4)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = if (remaining > 0) DebtRed else ProfitGreen
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "المبلغ المتبقي (يحسب تلقائياً):",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (remaining > 0) DebtRed else ProfitGreen
                                )
                            }
                            Text(
                                text = "${WorkshopRepository.formatAmount(remaining)} $currency",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = if (remaining > 0) DebtRed else ProfitGreen
                            )
                        }
                    }
                }
            }

            // Dates & Delivery Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "التواريخ وموعد التسليم",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = orderDate,
                            onValueChange = { orderDate = it },
                            label = { Text("تاريخ الطلب (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = deliveryDate,
                            onValueChange = { deliveryDate = it },
                            label = { Text("موعد التسليم") },
                            placeholder = { Text("مثال: بعد أسبوع، 2026-10-15") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    // Status Dropdown
                    ExposedDropdownMenuBox(
                        expanded = statusDropdownExpanded,
                        onExpandedChange = { statusDropdownExpanded = !statusDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = status,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownExpanded) },
                            label = { Text("حالة الطلب") },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = statusDropdownExpanded,
                            onDismissRequest = { statusDropdownExpanded = false }
                        ) {
                            OrderStatus.allStatuses.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        status = s
                                        statusDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات إضافية") },
                        placeholder = { Text("ملاحظات للورشة، موعد التركيب، شروط الزبون...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
