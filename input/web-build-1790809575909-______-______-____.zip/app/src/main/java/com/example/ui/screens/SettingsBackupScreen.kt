package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.WorkshopTopBar
import com.example.ui.theme.ForgeAmberDark
import com.example.ui.theme.ForgeAmberLight
import com.example.ui.theme.ForgeAmberPrimary
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SteelDark
import com.example.ui.viewmodel.WorkshopViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsBackupScreen(
    viewModel: WorkshopViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val mohammedPct by viewModel.mohammedPercentage.collectAsState()
    val rahenPct by viewModel.rahenPercentage.collectAsState()
    val defaultCurrency by viewModel.defaultCurrency.collectAsState()
    val workshopName by viewModel.workshopName.collectAsState()
    val workshopPhone by viewModel.workshopPhone.collectAsState()
    val workshopAddress by viewModel.workshopAddress.collectAsState()

    val orders by viewModel.ordersWithMods.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val withdrawals by viewModel.withdrawals.collectAsState()

    var mohammedShareInput by remember(mohammedPct) { mutableFloatStateOf(mohammedPct.toFloat()) }
    var currentCurrency by remember(defaultCurrency) { mutableStateOf(defaultCurrency) }

    var editWorkshopName by remember(workshopName) { mutableStateOf(workshopName) }
    var editWorkshopPhone by remember(workshopPhone) { mutableStateOf(workshopPhone) }
    var editWorkshopAddress by remember(workshopAddress) { mutableStateOf(workshopAddress) }

    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }

    val commonCurrencies = listOf("د.ع", "$", "ر.س", "ل.س", "ج.م")

    Scaffold(
        topBar = {
            WorkshopTopBar(
                title = "الإعدادات والنسخ الاحتياطي",
                subtitle = "بيانات الورشة ونسب الشراكة",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Partnership Percentage Configuration
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Percent,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "نسبة الشراكة بين الشريكين",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "يمكنك تعديل نسبة الأرباح بين محمد وراهن هنا وستنعكس فوراً على كافة الحسابات والتسويات.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Percentage Display Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            color = Color(0xFFEDE9FE),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "محمد: ${mohammedShareInput.toInt()}%",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF7C3AED),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        Surface(
                            color = Color(0xFFDBEAFE),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "راهن: ${(100 - mohammedShareInput).toInt()}%",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Slider(
                        value = mohammedShareInput,
                        onValueChange = { mohammedShareInput = it },
                        valueRange = 0f..100f,
                        steps = 99,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("partner_percentage_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { mohammedShareInput = 50f },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مناصفة (50% - 50%)")
                        }

                        Button(
                            onClick = {
                                val m = mohammedShareInput.toDouble()
                                val r = 100.0 - m
                                viewModel.updatePartnerPercentages(m, r)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ForgeAmberPrimary, contentColor = SteelDark),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_percentages_button")
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حفظ النسب")
                        }
                    }
                }
            }

            // Section 2: Default Currency
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CurrencyExchange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "العملة الافتراضية للتطبيق",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        commonCurrencies.forEach { cur ->
                            FilterChip(
                                selected = currentCurrency == cur,
                                onClick = {
                                    currentCurrency = cur
                                    viewModel.updateDefaultCurrency(cur)
                                },
                                label = { Text(cur, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }
                }
            }

            // Section 3: Workshop Details
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Business,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بيانات الورشة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = editWorkshopName,
                        onValueChange = { editWorkshopName = it },
                        label = { Text("اسم الورشة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = editWorkshopPhone,
                        onValueChange = { editWorkshopPhone = it },
                        label = { Text("هاتف الورشة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = editWorkshopAddress,
                        onValueChange = { editWorkshopAddress = it },
                        label = { Text("عنوان / موقع الورشة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            viewModel.updateWorkshopInfo(editWorkshopName, editWorkshopPhone, editWorkshopAddress)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForgeAmberPrimary, contentColor = SteelDark),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("حفظ بيانات الورشة")
                    }
                }
            }

            // Section 4: Local Persistence & Backup
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Storage,
                            contentDescription = null,
                            tint = ProfitGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حفظ البيانات والنسخ الاحتياطي المحلي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "كافة بيانات الورشة (الطلبات، العملاء، المصاريف، السحوبات، التعديلات) محفوظة تلقائياً ومحلياً على هاتفك باستخدام قاعدة بيانات Room، ولا تضيع عند إغلاق التطبيق.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Data stats summary
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${orders.size} طلب", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Text("${customers.size} عميل", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Text("${expenses.size} مصروف", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Text("${withdrawals.size} سحب", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val backupSummary = buildString {
                                    appendLine("📋 تقرير النسخة الاحتياطية - حسابات الورشة")
                                    appendLine("محمد & راهن")
                                    appendLine("عدد الطلبات: ${orders.size}")
                                    appendLine("عدد العملاء: ${customers.size}")
                                    appendLine("عدد المصاريف: ${expenses.size}")
                                    appendLine("عدد السحوبات: ${withdrawals.size}")
                                    appendLine("نسبة الشراكة: محمد ($mohammedPct%) - راهن ($rahenPct%)")
                                }
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, backupSummary)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "مشاركة تقرير النسخة الاحتياطية"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7), contentColor = Color.White),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_backup_button")
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مشاركة ملخص البيانات")
                        }

                        OutlinedButton(
                            onClick = { viewModel.reloadSampleData() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("بيانات تجريبية")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
