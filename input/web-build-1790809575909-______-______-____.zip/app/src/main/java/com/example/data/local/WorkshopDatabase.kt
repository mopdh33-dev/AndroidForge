package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Customer
import com.example.data.model.Expense
import com.example.data.model.Order
import com.example.data.model.OrderModification
import com.example.data.model.PartnerWithdrawal
import com.example.data.model.WorkshopSetting

@Database(
    entities = [
        Customer::class,
        Order::class,
        OrderModification::class,
        Expense::class,
        PartnerWithdrawal::class,
        WorkshopSetting::class
    ],
    version = 1,
    exportSchema = false
)
abstract class WorkshopDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun orderDao(): OrderDao
    abstract fun orderModificationDao(): OrderModificationDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun partnerWithdrawalDao(): PartnerWithdrawalDao
    abstract fun workshopSettingDao(): WorkshopSettingDao

    companion object {
        @Volatile
        private var INSTANCE: WorkshopDatabase? = null

        fun getDatabase(context: Context): WorkshopDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WorkshopDatabase::class.java,
                    "workshop_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
